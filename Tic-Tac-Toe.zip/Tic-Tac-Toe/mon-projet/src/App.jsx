import React, { useState } from "react";

import Board from "./components/Board";

import ResetButton from "./components/ResetButton";

import "./styles/App.css";

const App = () => {

  const [board, setBoard] = useState(Array(9).fill(null));

  const [isXNext, setIsXNext] = useState(true);

  const resetGame = () => {

    setBoard(Array(9).fill(null));

    setIsXNext(true);

  };

  return (
<div className="app">
<h1>Tic Tac Toe</h1>
<Board board={board} setBoard={setBoard} isXNext={isXNext} setIsXNext={setIsXNext} />
<ResetButton resetGame={resetGame} />
</div>

  );

};

export default App;