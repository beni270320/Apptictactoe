import React from "react";

import Square from "./Square";

import calculateWinner from "../Store/calculateWinner";

import "../styles/App.css";

const Board = ({ board, setBoard, isXNext, setIsXNext }) => {

  const winner = calculateWinner(board);

  const handleClick = (index) => {

    if (board[index] || winner) return;

    const newBoard = [...board];

    newBoard[index] = isXNext ? "X" : "O";

    setBoard(newBoard);

    setIsXNext(!isXNext);

  };

  return (
<div>

      {winner ? <h2>Gagnant : {winner}</h2> : <h2>Prochain joueur : {isXNext ? "X" : "O"}</h2>}
<div className="board">

        {board.map((value, index) => (
<Square key={index} value={value} onClick={() => handleClick(index)} />

        ))}
</div>
</div>

  );

};

export default Board;