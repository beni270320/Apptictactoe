import React from "react";

import "../styles/App.css";

const ResetButton = ({ resetGame }) => {

  return (
<button className="reset-button" onClick={resetGame}>

      Réinitialiser
</button>

  );

};

export default ResetButton ;